/*-
 * Copyright (c) 2003-2007 Tim Kientzle
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR(S) ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR(S) BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 * This code borrows heavily from "compress" source code, which is
 * protected by the following copyright.  (Clause 3 dropped by request
 * of the Regents.)
 */

/*-
 * Copyright (c) 1985, 1986, 1992, 1993
 *	The Regents of the University of California.  All rights reserved.
 *
 * This code is derived from software contributed to Berkeley by
 * Diomidis Spinellis and James A. Woods, derived from original
 * work by Spencer Thomas and Joseph Orost.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 4. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */


#include "archive_platform.h"

#ifdef HAVE_ERRNO_H
#include <errno.h>
#endif
#ifdef HAVE_STDLIB_H
#include <stdlib.h>
#endif
#ifdef HAVE_STRING_H
#include <string.h>
#endif
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#include "archive.h"
#include "archive_private.h"
#include "archive_read_private.h"

/*
 * Because LZW decompression is pretty simple, I've just implemented
 * the whole decompressor here (cribbing from "compress" source code,
 * of course), rather than relying on an external library.  I have
 * made an effort to clarify and simplify the algorithm, so the
 * names and structure here don't exactly match those used by compress.
 */

struct compress {
	/* Input variables. */
	const unsigned char	*next_in;
	size_t			 avail_in;
	size_t			 consume_unnotified;
	int			 bit_buffer;
	int			 bits_avail;
	size_t			 bytes_in_section;

	/* Output variables. */
	size_t			 out_block_size;
	void			*out_block;

	/* Decompression status variables. */
	int			 initialized;
	int			 use_reset_code;
	int			 end_of_stream;	/* EOF status. */
	int			 maxcode;	/* Largest code. */
	int			 maxcode_bits;	/* Length of largest code. */
	int			 section_end_code; /* When to increase bits. */
	int			 bits;		/* Current code length. */
	int			 oldcode;	/* Previous code. */
	int			 finbyte;	/* Last byte of prev code. */

	/* Dictionary. */
	int			 free_ent;       /* Next dictionary entry. */
	unsigned char		 suffix[65536];
	uint16_t		 prefix[65536];

	/*
	 * Scratch area for expanding dictionary entries.  Note:
	 * "worst" case here comes from compressing /dev/zero: the
	 * last code in the dictionary will code a sequence of
	 * 65536-256 zero bytes.  Thus, we need stack space to expand
	 * a 65280-byte dictionary entry.  (Of course, 32640:1
	 * compression could also be considered the "best" case. ;-)
	 */
	unsigned char		*stackp;
	unsigned char		 stack[65300];
};

static int	compress_bidder_bid(struct archive_read_filter_bidder *, struct archive_read_filter *);
static int	compress_bidder_init(struct archive_read_filter *);

static ssize_t	compress_filter_read(struct archive_read_filter *, const void **);
static int	compress_filter_close(struct archive_read_filter *);

static int	getbits(struct archive_read_filter *, int n);
static int	next_code(struct archive_read_filter *);

#if ARCHIVE_VERSION_NUMBER < 4000000
/* Deprecated; remove in libarchive 4.0 */
int
archive_read_support_compression_compress(struct archive *a)
{
	return archive_read_support_filter_compress(a);
}
#endif

static const struct archive_read_filter_bidder_vtable
compress_bidder_vtable = {
	.bid = compress_bidder_bid,
	.init = compress_bidder_init,
};

int
archive_read_support_filter_compress(struct archive *_a)
{
	struct archive_read *a = (struct archive_read *)_a;

	return __archive_read_register_bidder(a, NULL,
			&compress_bidder_vtable);
}

/*
 * Test whether we can handle this data.
 * This logic returns zero if any part of the signature fails.
 */
static int
compress_bidder_bid(struct archive_read_filter_bidder *b,
    struct archive_read_filter *f)
{
	const unsigned char *buffer;
	int bits_checked;

	(void)b; /* UNUSED */

	/* Shortest valid compress file is 3 bytes. */
	buffer = __archive_read_filter_ahead(f, 3, NULL);

	if (buffer == NULL)
		return (0);

	bits_checked = 0;
	/* First two bytes are the magic value */
	if (buffer[0] != 0x1F || buffer[1] != 0x9D)
		return (0);
	/* Third byte holds compression parameters. */
	if (buffer[2] & 0x20) /* Reserved bit, must be zero. */
		return (0);
	if (buffer[2] & 0x40) /* Reserved bit, must be zero. */
		return (0);
	bits_checked += 18;

	return (bits_checked);
}

static const struct archive_read_filter_vtable
compress_reader_vtable = {
	.read = compress_filter_read,
	.close = compress_filter_close,
};

/*
 * Setup the callbacks.
 */
static int
compress_bidder_init(struct archive_read_filter *f)
{
	struct compress *compress;
	static const size_t out_block_size = 64 * 1024;
	void *out_block;

	f->code = ARCHIVE_FILTER_COMPRESS;
	f->name = "compress (.Z)";

	compress = calloc(1, sizeof(*compress));
	out_block = malloc(out_block_size);
	if (compress == NULL || out_block == NULL) {
		free(out_block);
		free(compress);
		archive_set_error(&f->archive->archive, ENOMEM,
		    "Can't allocate data for %s decompression",
		    f->name);
		return (ARCHIVE_FATAL);
	}

	f->data = compress;
	compress->out_block_size = out_block_size;
	compress->out_block = out_block;
	f->vtable = &compress_reader_vtable;

	return (ARCHIVE_OK);
}

static int
compress_filter_init(struct archive_read_filter *f)
{
	struct compress *compress = f->data;
	int code;

	compress->initialized = 1;

	(void)getbits(f, 8); /* Skip first signature byte. */
	(void)getbits(f, 8); /* Skip second signature byte. */

	/* Get compression parameters. */
	code = getbits(f, 8);
	if (code < 0 || (code & 0x1f) > 16) {
		archive_set_error(&f->archive->archive, -1,
		    "Invalid compressed data");
		return (ARCHIVE_FATAL);
	}
	compress->maxcode_bits = code & 0x1f;
	compress->maxcode = (1 << compress->maxcode_bits);
	compress->use_reset_code = code & 0x80;

	/* Initialize decompressor. */
	compress->free_ent = 256;
	compress->stackp = compress->stack;
	if (compress->use_reset_code)
		compress->free_ent++;
	compress->bits = 9;
	compress->section_end_code = (1<<compress->bits) - 1;
	compress->oldcode = -1;
	for (code = 255; code >= 0; code--) {
		compress->prefix[code] = 0;
		compress->suffix[code] = code;
	}
	next_code(f);

	return (ARCHIVE_OK);
}

/*
 * Return a block of data from the decompression buffer.  Decompress more
 * as necessary.
 */
static ssize_t
compress_filter_read(struct archive_read_filter *f, const void **pblock)
{
	struct compress *compress = f->data;
	unsigned char *p, *start, *end;
	int ret;

	if (!compress->initialized) {
		ret = compress_filter_init(f);
		if (ret != ARCHIVE_OK)
			return (ret);
	}
	if (compress->end_of_stream) {
		*pblock = NULL;
		return (0);
	}
	p = start = (unsigned char *)compress->out_block;
	end = start + compress->out_block_size;

	while (p < end && !compress->end_of_stream) {
		if (compress->stackp > compress->stack) {
			*p++ = *--compress->stackp;
		} else {
			ret = next_code(f);
			if (ret == -1)
				compress->end_of_stream = ret;
			else if (ret != ARCHIVE_OK)
				return (ret);
		}
	}

	*pblock = start;
	return (p - start);
}

/*
 * Close and release the filter.
 */
static int
compress_filter_close(struct archive_read_filter *f)
{
	struct compress *compress = f->data;

	free(compress->out_block);
	free(compress);
	return (ARCHIVE_OK);
}

/*
 * Process the next code and fill the stack with the expansion
 * of the code.  Returns ARCHIVE_FATAL if there is a fatal I/O or
 * format error, ARCHIVE_EOF if we hit end of data, ARCHIVE_OK otherwise.
 */
static int
next_code(struct archive_read_filter *f)
{
	struct compress *compress = f->data;
	int code, newcode;

again:
	code = newcode = getbits(f, compress->bits);
	if (code < 0)
		return (code);

	/* If it's a reset code, reset the dictionary. */
	if ((code == 256) && compress->use_reset_code) {
		/*
		 * The original 'compress' implementation blocked its
		 * I/O in a manner that resulted in junk bytes being
		 * inserted after every reset.  The next section skips
		 * this junk.  (Yes, the number of *bytes* to skip is
		 * a function of the current *bit* length.)
		 */
		int skip_bytes =  compress->bits -
		    (compress->bytes_in_section % compress->bits);
		skip_bytes %= compress->bits;
		compress->bits_avail = 0; /* Discard rest of this byte. */
		while (skip_bytes-- > 0) {
			code = getbits(f, 8);
			if (code < 0)
				return (code);
		}
		/* Now, actually do the reset. */
		compress->bytes_in_section = 0;
		compress->bits = 9;
		compress->section_end_code = (1 << compress->bits) - 1;
		compress->free_ent = 257;
		compress->oldcode = -1;
		goto again;
	}

	if (code > compress->free_ent
	    || (code == compress->free_ent && compress->oldcode < 0)) {
		/* An invalid code is a fatal error. */
		archive_set_error(&(f->archive->archive), -1,
		    "Invalid compressed data");
		return (ARCHIVE_FATAL);
	}

	/* Special case for KwKwK string. */
	if (code >= compress->free_ent) {
		*compress->stackp++ = compress->finbyte;
		code = compress->oldcode;
	}

	/* Generate output characters in reverse order. */
	while (code >= 256) {
		*compress->stackp++ = compress->suffix[code];
		code = compress->prefix[code];
	}
	*compress->stackp++ = compress->finbyte = code;

	/* Generate the new entry. */
	code = compress->free_ent;
	if (code < compress->maxcode && compress->oldcode >= 0) {
		compress->prefix[code] = compress->oldcode;
		compress->suffix[code] = compress->finbyte;
		++compress->free_ent;
	}
	if (compress->free_ent > compress->section_end_code) {
		compress->bits++;
		compress->bytes_in_section = 0;
		if (compress->bits == compress->maxcode_bits)
			compress->section_end_code = compress->maxcode;
		else
			compress->section_end_code = (1 << compress->bits) - 1;
	}

	/* Remember previous code. */
	compress->oldcode = newcode;
	return (ARCHIVE_OK);
}

/*
 * Return next 'n' bits from stream.
 *
 * -1 indicates end of available data.
 */
static int
getbits(struct archive_read_filter *f, int n)
{
	struct compress *compress = f->data;
	int code;
	ssize_t ret;
	static const int mask[] = {
		0x00, 0x01, 0x03, 0x07, 0x0f, 0x1f, 0x3f, 0x7f, 0xff,
		0x1ff, 0x3ff, 0x7ff, 0xfff, 0x1fff, 0x3fff, 0x7fff, 0xffff
	};

	while (compress->bits_avail < n) {
		if (compress->avail_in <= 0) {
			if (compress->consume_unnotified) {
				__archive_read_filter_consume(f->upstream,
					compress->consume_unnotified);
				compress->consume_unnotified = 0;
			}
			compress->next_in
			    = __archive_read_filter_ahead(f->upstream,
				1, &ret);
			if (ret == 0)
				return (-1);
			if (compress->next_in == NULL)
				return (ARCHIVE_FATAL);
			compress->consume_unnotified = compress->avail_in = ret;
		}
		compress->bit_buffer |= *compress->next_in++ << compress->bits_avail;
		compress->avail_in--;
		compress->bits_avail += 8;
		compress->bytes_in_section++;
	}

	code = compress->bit_buffer;
	compress->bit_buffer >>= n;
	compress->bits_avail -= n;

	return (code & mask[n]);
}

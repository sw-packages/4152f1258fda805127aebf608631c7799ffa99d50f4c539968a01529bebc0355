/*-
 * Copyright (c) 2014 Michihiro NAKAJIMA
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR(S) ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR(S) BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "archive_platform.h"

#ifdef HAVE_ERRNO_H
#include <errno.h>
#endif
#include <stdio.h>
#ifdef HAVE_STDLIB_H
#include <stdlib.h>
#endif
#ifdef HAVE_STRING_H
#include <string.h>
#endif
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif
#ifdef HAVE_LZ4_H
#include <lz4.h>
#endif

#include "archive.h"
#include "archive_endian.h"
#include "archive_integer.h"
#include "archive_private.h"
#include "archive_read_private.h"
#include "archive_xxhash.h"

#define LZ4_MAGICNUMBER		0x184d2204
#define LZ4_LEGACY		0x184c2102

// Note: LZ4 and zstd share the same skippable frame format with the same magic numbers.
#define LZ4_SKIPPABLE_START 0x184D2A50
#define LZ4_SKIPPABLE_MASK 0xFFFFFFF0

#if defined(HAVE_LIBLZ4)
struct lz4 {
	enum {  SELECT_STREAM,
		READ_DEFAULT_STREAM,
		READ_DEFAULT_BLOCK,
		READ_LEGACY_STREAM,
		READ_LEGACY_BLOCK,
	}		stage;
	struct {
		unsigned block_independence:1;
		unsigned block_checksum:3;
		unsigned stream_size:1;
		unsigned stream_checksum:1;
		unsigned preset_dictionary:1;
		int	 block_maximum_size;
	} flags;
	int64_t		 stream_size;
	char		*out_block;
	size_t		 out_block_size;

	/* Bytes read but not yet consumed via __archive_read_consume() */
	size_t		 unconsumed;
	size_t		 decoded_size;
	void		*xxh32_state;

	char		 eof; /* True = found end of compressed data. */
};

#define LEGACY_BLOCK_SIZE	(8 * 1024 * 1024)

/* Lz4 filter */
static ssize_t	lz4_filter_read(struct archive_read_filter *, const void **);
static int	lz4_filter_close(struct archive_read_filter *);
#endif

/*
 * Note that we can detect lz4 archives even if we can't decompress
 * them.  (In fact, we like detecting them because we can give better
 * error messages.)
 */
static int	lz4_reader_bid(struct archive_read_filter_bidder *, struct archive_read_filter *);
static int	lz4_reader_init(struct archive_read_filter *);
#if defined(HAVE_LIBLZ4)
static ssize_t  lz4_filter_read_default_stream(struct archive_read_filter *,
		    const void **);
static ssize_t  lz4_filter_read_legacy_stream(struct archive_read_filter *,
		    const void **);
#endif

static const struct archive_read_filter_bidder_vtable
lz4_bidder_vtable = {
	.bid = lz4_reader_bid,
	.init = lz4_reader_init,
};

int
archive_read_support_filter_lz4(struct archive *_a)
{
	struct archive_read *a = (struct archive_read *)_a;

	if (__archive_read_register_bidder(a, NULL,
				&lz4_bidder_vtable) != ARCHIVE_OK)
		return (ARCHIVE_FATAL);

#if defined(HAVE_LIBLZ4)
	return (ARCHIVE_OK);
#else
	archive_set_error(_a, ARCHIVE_ERRNO_MISC,
	    "Using external lz4 program");
	return (ARCHIVE_WARN);
#endif
}

/*
 * Test whether we can handle this data.
 *
 * This logic returns zero if any part of the signature fails.  It
 * also tries to Do The Right Thing if a very short buffer prevents us
 * from verifying as much as we would like.
 */
static int
lz4_reader_bid(struct archive_read_filter_bidder *b,
    struct archive_read_filter *f)
{
	const unsigned char *buffer;
	ssize_t avail;
	int bits_checked = 0;
	const size_t min_lz4_archive_size = 11;

	/*
	 * LZ4 skippable frames contain a 4 byte magic number followed by
	 * a 4 byte frame data size, then that number of bytes of data.
	 * Regular frames contain a 4 byte magic number followed by a 2-14
	 * byte frame header, some data, and a 3 byte end marker.
	 */
	const size_t min_lz4_frame_size = 8;

	size_t offset_in_buffer = 0;
	const size_t max_lookahead = 64 * 1024;
	uint32_t magic_number;

	(void)b; /* UNUSED */

	/*
	 * Zstd and LZ4 skippable frame magic numbers are identical. To
	 * differentiate these two, we need to look for a non-skippable
	 * frame.
	 */

	/* Minimal lz4 archive is 11 bytes. */
	buffer = __archive_read_filter_ahead(f, min_lz4_archive_size,
	    &avail);
	if (buffer == NULL)
		return (0);

	magic_number = archive_le32dec(buffer);

	while ((magic_number & LZ4_SKIPPABLE_MASK) == LZ4_SKIPPABLE_START) {
		size_t min;
		uint32_t frame_data_size;

		/* Skip over the magic number */
		bits_checked += 28;
		offset_in_buffer += 4;

		/* Ensure that we can read another 4 bytes. */
		if (offset_in_buffer + 4 > (size_t)avail) {
			buffer = __archive_read_filter_ahead(f,
			    offset_in_buffer + 4, &avail);
			if (buffer == NULL)
				return (0);
		}

		frame_data_size = archive_le32dec(buffer + offset_in_buffer);

		/* Skip over the 4 frame data size bytes */
		offset_in_buffer += 4;

		/* Skip over the value stored there. */
		if (archive_ckd_add_size(&offset_in_buffer,
		    offset_in_buffer, frame_data_size))
			return (0);

		/*
		 * There should be at least one more frame
		 * if this is LZ4 data.
		 */
		if (archive_ckd_add_size(&min,
		    offset_in_buffer, min_lz4_frame_size) ||
		    min > max_lookahead)
			return (0);
		/* TODO: should this be >= ? */
		if (min > (size_t)avail) {
			buffer = __archive_read_filter_ahead(f,
			    min, &avail);
			if (buffer == NULL)
				return (0); 
		}

		magic_number = archive_le32dec(buffer + offset_in_buffer);
	}

	/*
	 * We have skipped over any skippable frames. Either a regular LZ4 frame
	 * follows, or this isn't LZ4 data.
	 */

	buffer = buffer + offset_in_buffer;

	if (magic_number == LZ4_MAGICNUMBER) {
		unsigned char flag, BD;

		bits_checked += 32;
		/* Next follows a stream descriptor. */
		/* Descriptor Flags. */
		flag = buffer[4];
		/* A version number must be "01". */
		if (((flag & 0xc0) >> 6) != 1)
			return (0);
		/* A reserved bit must be "0". */
		if (flag & 2)
			return (0);
		bits_checked += 8;
		BD = buffer[5];
		/* A block maximum size should be more than 3. */
		if (((BD & 0x70) >> 4) < 4)
			return (0);
		/* Reserved bits must be "0". */
		if (BD & ~0x70)
			return (0);
		bits_checked += 8;

		return (bits_checked);
	}

	if (magic_number == LZ4_LEGACY) {
		bits_checked += 32;
		return (bits_checked);
	}

	return (0);
}

#if !defined(HAVE_LIBLZ4)

/*
 * If we don't have the library on this system, we can't do the
 * decompression directly.  We can, however, try to run "lz4 -d -q"
 * in case that's available.
 */
static int
lz4_reader_init(struct archive_read_filter *f)
{
	int r;

	r = __archive_read_program(f, "lz4 -d -q");
	/* Note: We set the format here even if __archive_read_program()
	 * above fails.  We do, after all, know what the format is
	 * even if we weren't able to read it. */
	f->code = ARCHIVE_FILTER_LZ4;
	f->name = "lz4";
	return (r);
}


#else

static const struct archive_read_filter_vtable
lz4_reader_vtable = {
	.read = lz4_filter_read,
	.close = lz4_filter_close,
};

/*
 * Setup the callbacks.
 */
static int
lz4_reader_init(struct archive_read_filter *f)
{
	struct lz4 *lz4;

	f->code = ARCHIVE_FILTER_LZ4;
	f->name = "lz4";

	lz4 = calloc(1, sizeof(*lz4));
	if (lz4 == NULL) {
		archive_set_error(&f->archive->archive, ENOMEM,
		    "Can't allocate data for lz4 decompression");
		return (ARCHIVE_FATAL);
	}

	f->data = lz4;
	lz4->stage = SELECT_STREAM;
	f->vtable = &lz4_reader_vtable;

	return (ARCHIVE_OK);
}

static int
lz4_allocate_out_block(struct archive_read_filter *f)
{
	struct lz4 *lz4 = f->data;
	size_t out_block_size = lz4->flags.block_maximum_size;
	void *out_block;

	if (!lz4->flags.block_independence)
		out_block_size += 64 * 1024;
	if (lz4->out_block_size < out_block_size) {
		free(lz4->out_block);
		lz4->out_block = NULL;
		out_block = malloc(out_block_size);
		if (out_block == NULL) {
			lz4->out_block_size = 0;
			archive_set_error(&f->archive->archive, ENOMEM,
			    "Can't allocate data for lz4 decompression");
			return (ARCHIVE_FATAL);
		}
		lz4->out_block_size = out_block_size;
		lz4->out_block = out_block;
	}
	if (!lz4->flags.block_independence)
		memset(lz4->out_block, 0, 64 * 1024);
	return (ARCHIVE_OK);
}

static int
lz4_allocate_out_block_for_legacy(struct archive_read_filter *f)
{
	struct lz4 *lz4 = f->data;
	size_t out_block_size = LEGACY_BLOCK_SIZE;
	void *out_block;

	if (lz4->out_block_size < out_block_size) {
		free(lz4->out_block);
		lz4->out_block = NULL;
		out_block = malloc(out_block_size);
		if (out_block == NULL) {
			lz4->out_block_size = 0;
			archive_set_error(&f->archive->archive, ENOMEM,
			    "Can't allocate data for lz4 decompression");
			return (ARCHIVE_FATAL);
		}
		lz4->out_block_size = out_block_size;
		lz4->out_block = out_block;
	}
	return (ARCHIVE_OK);
}

/*
 * Return the next block of decompressed data.
 */
static ssize_t
lz4_filter_read(struct archive_read_filter *f, const void **p)
{
	struct lz4 *lz4 = f->data;
	ssize_t ret;

	if (lz4->eof) {
		*p = NULL;
		return (0);
	}

	__archive_read_filter_consume(f->upstream, lz4->unconsumed);
	lz4->unconsumed = 0;

	switch (lz4->stage) {
	case SELECT_STREAM:
		break;
	case READ_DEFAULT_STREAM:
	case READ_LEGACY_STREAM:
		/* Reading an lz4 stream already failed. */
		archive_set_error(&f->archive->archive,
		    ARCHIVE_ERRNO_MISC, "Invalid sequence");
		return (ARCHIVE_FATAL);
	case READ_DEFAULT_BLOCK:
		ret = lz4_filter_read_default_stream(f, p);
		if (ret != 0 || lz4->stage != SELECT_STREAM)
			return ret;
		break;
	case READ_LEGACY_BLOCK:
		ret = lz4_filter_read_legacy_stream(f, p);
		if (ret != 0 || lz4->stage != SELECT_STREAM)
			return ret;
		break;
	default:
		archive_set_error(&f->archive->archive,
		    ARCHIVE_ERRNO_MISC, "Program error");
		return (ARCHIVE_FATAL);
	}

	while (lz4->stage == SELECT_STREAM) {
		const char *read_buf;

		/* Read a magic number. */
		read_buf = __archive_read_filter_ahead(f->upstream, 4,
				NULL);
		if (read_buf == NULL) {
			lz4->eof = 1;
			*p = NULL;
			return (0);
		}
		uint32_t number = archive_le32dec(read_buf);
		__archive_read_filter_consume(f->upstream, 4);
		if (number == LZ4_MAGICNUMBER)
			return lz4_filter_read_default_stream(f, p);
		else if (number == LZ4_LEGACY)
			return lz4_filter_read_legacy_stream(f, p);
		else if ((number & LZ4_SKIPPABLE_MASK) == LZ4_SKIPPABLE_START) {
			read_buf = __archive_read_filter_ahead(
				f->upstream, 4, NULL);
			if (read_buf == NULL) {
				archive_set_error(
				    &f->archive->archive,
		    		    ARCHIVE_ERRNO_MISC,
				    "Malformed lz4 data");
				return (ARCHIVE_FATAL);
			}
			int64_t skip_bytes = archive_le32dec(read_buf);
			if (__archive_read_filter_consume(f->upstream,
			    4 + skip_bytes) < 0) {
				archive_set_error(
				    &f->archive->archive,
				    ARCHIVE_ERRNO_MISC,
				    "Malformed lz4 data");
				return (ARCHIVE_FATAL);
			}
		} else {
			/* Ignore following unrecognized data. */
			lz4->eof = 1;
			*p = NULL;
			return (0);
		}
	}
	lz4->eof = 1;
	*p = NULL;
	return (0);
}

static int
lz4_filter_read_descriptor(struct archive_read_filter *f)
{
	struct lz4 *lz4 = f->data;
	const char *read_buf;
	ssize_t bytes_remaining;
	ssize_t descriptor_bytes;
	unsigned char flag, bd;
	unsigned int chsum, chsum_verifier;

	/* Make sure we have 2 bytes for flags. */
	read_buf = __archive_read_filter_ahead(f->upstream, 2,
	    &bytes_remaining);
	if (read_buf == NULL) {
		archive_set_error(&f->archive->archive,
		    ARCHIVE_ERRNO_MISC,
		    "truncated lz4 input");
		return (ARCHIVE_FATAL);
	}

	/*
	   Parse flags.
	 */
	flag = (unsigned char)read_buf[0];
	/* Verify version number. */
	if ((flag & 0xc0) != 1<<6)
		goto malformed_error;
	/* A reserved bit must be zero. */
	if (flag & 0x02)
		goto malformed_error;
	lz4->flags.block_independence = (flag & 0x20) != 0;
	lz4->flags.block_checksum = (flag & 0x10)?4:0;
	lz4->flags.stream_size = (flag & 0x08) != 0;
	lz4->flags.stream_checksum = (flag & 0x04) != 0;
	lz4->flags.preset_dictionary = (flag & 0x01) != 0;

	/* BD */
	bd = (unsigned char)read_buf[1];
	/* Reserved bits must be zero. */
	if (bd & 0x8f)
		goto malformed_error;
	/* Get a maximum block size. */
	switch (read_buf[1] >> 4) {
	case 4: /* 64 KB */
		lz4->flags.block_maximum_size = 64 * 1024;
		break;
	case 5: /* 256 KB */
		lz4->flags.block_maximum_size = 256 * 1024;
		break;
	case 6: /* 1 MB */
		lz4->flags.block_maximum_size = 1024 * 1024;
		break;
	case 7: /* 4 MB */
		lz4->flags.block_maximum_size = 4 * 1024 * 1024;
		break;
	default:
		goto malformed_error;
	}

	/* Read the whole descriptor in a stream block. */
	descriptor_bytes = 3;
	if (lz4->flags.stream_size)
		descriptor_bytes += 8;
	if (lz4->flags.preset_dictionary)
		descriptor_bytes += 4;
	if (bytes_remaining < descriptor_bytes) {
		read_buf = __archive_read_filter_ahead(f->upstream,
		    descriptor_bytes, &bytes_remaining);
		if (read_buf == NULL) {
			archive_set_error(&f->archive->archive,
			    ARCHIVE_ERRNO_MISC,
			    "truncated lz4 input");
			return (ARCHIVE_FATAL);
		}
	}
	/* Check if a descriptor is corrupted */
	chsum = __archive_xxhash.XXH32(read_buf, (int)descriptor_bytes -1, 0);
	chsum = (chsum >> 8) & 0xff;
	chsum_verifier = read_buf[descriptor_bytes-1] & 0xff;
#ifndef DONT_FAIL_ON_CRC_ERROR
	if (chsum != chsum_verifier)
		goto malformed_error;
#endif

	__archive_read_filter_consume(f->upstream, descriptor_bytes);

	/* Make sure we have a large enough buffer for uncompressed data. */
	if (lz4_allocate_out_block(f) != ARCHIVE_OK)
		return (ARCHIVE_FATAL);
	if (lz4->flags.stream_checksum) {
		lz4->xxh32_state = __archive_xxhash.XXH32_init(0);
		if (lz4->xxh32_state == NULL)
			return (ARCHIVE_FATAL);
	}

	lz4->decoded_size = 0;
	/* Success */
	return (ARCHIVE_OK);
malformed_error:
	archive_set_error(&f->archive->archive, ARCHIVE_ERRNO_MISC,
	    "malformed lz4 data");
	return (ARCHIVE_FATAL);
}

static ssize_t
lz4_filter_read_data_block(struct archive_read_filter *f, const void **p)
{
	struct lz4 *lz4 = f->data;
	ssize_t compressed_size;
	const char *read_buf;
	int checksum_size;
	ssize_t uncompressed_size;
	size_t prefix64k;

	*p = NULL;

	/* Make sure we have 4 bytes for a block size. */
	read_buf = __archive_read_filter_ahead(f->upstream, 4, NULL);
	if (read_buf == NULL)
		goto truncated_error;
	compressed_size = archive_le32dec(read_buf);
	if ((compressed_size & 0x7fffffff) > lz4->flags.block_maximum_size)
		goto malformed_error;
	/* A compressed size == 0 means the end of stream blocks. */
	if (compressed_size == 0) {
		__archive_read_filter_consume(f->upstream, 4);
		return 0;
	}

	checksum_size = lz4->flags.block_checksum;
	/* Check if the block is uncompressed. */
	if (compressed_size & 0x80000000U) {
		compressed_size &= 0x7fffffff;
		uncompressed_size = compressed_size;
	} else
		uncompressed_size = 0;/* Unknown yet. */

	/*
	  Unfortunately, lz4 decompression API requires a whole block
	  for its decompression speed, so we read a whole block and allocate
	  a huge buffer used for decoded data.
	*/
	read_buf = __archive_read_filter_ahead(f->upstream,
	    4 + compressed_size + checksum_size, NULL);
	if (read_buf == NULL)
		goto truncated_error;

	/* Optional processing, checking a block sum. */
	if (checksum_size) {
		unsigned int chsum = __archive_xxhash.XXH32(
			read_buf + 4, (int)compressed_size, 0);
		unsigned int chsum_block =
		    archive_le32dec(read_buf + 4 + compressed_size);
#ifndef DONT_FAIL_ON_CRC_ERROR
		if (chsum != chsum_block)
			goto malformed_error;
#endif
	}


	/* If the block is uncompressed, there is nothing to do. */
	if (uncompressed_size) {
		/* Prepare a prefix 64k block for next block. */
		if (!lz4->flags.block_independence) {
			prefix64k = 64 * 1024;
			if (uncompressed_size < (ssize_t)prefix64k) {
				memcpy(lz4->out_block
					+ prefix64k - uncompressed_size,
				    read_buf + 4,
				    uncompressed_size);
				memset(lz4->out_block, 0,
				    prefix64k - uncompressed_size);
			} else {
				memcpy(lz4->out_block,
				    read_buf + 4
					+ uncompressed_size - prefix64k,
				    prefix64k);
			}
			lz4->decoded_size = 0;
		}
		lz4->unconsumed = 4 + uncompressed_size + checksum_size;
		*p = read_buf + 4;
		return uncompressed_size;
	}

	/*
	   Decompress a block data.
	 */
	if (lz4->flags.block_independence) {
		prefix64k = 0;
		uncompressed_size = LZ4_decompress_safe(read_buf + 4,
		    lz4->out_block, (int)compressed_size,
		    lz4->flags.block_maximum_size);
	} else {
		prefix64k = 64 * 1024;
		if (lz4->decoded_size) {
			if (lz4->decoded_size < prefix64k) {
				memmove(lz4->out_block
					+ prefix64k - lz4->decoded_size,
				    lz4->out_block + prefix64k,
				    lz4->decoded_size);
				memset(lz4->out_block, 0,
				    prefix64k - lz4->decoded_size);
			} else {
				memmove(lz4->out_block,
				    lz4->out_block + lz4->decoded_size,
				    prefix64k);
			}
		}
#if LZ4_VERSION_MAJOR >= 1 && LZ4_VERSION_MINOR >= 7
		uncompressed_size = LZ4_decompress_safe_usingDict(
		    read_buf + 4,
		    lz4->out_block + prefix64k, (int)compressed_size,
		    lz4->flags.block_maximum_size,
		    lz4->out_block,
		    (int)prefix64k);
#else
		uncompressed_size = LZ4_decompress_safe_withPrefix64k(
		    read_buf + 4,
		    lz4->out_block + prefix64k, (int)compressed_size,
		    lz4->flags.block_maximum_size);
#endif
	}

	/* Check if an error occurred in the decompression process. */
	if (uncompressed_size < 0) {
		archive_set_error(&(f->archive->archive),
		    ARCHIVE_ERRNO_MISC, "lz4 decompression failed");
		return (ARCHIVE_FATAL);
	}

	lz4->unconsumed = 4 + compressed_size + checksum_size;
	*p = lz4->out_block + prefix64k;
	lz4->decoded_size = uncompressed_size;
	return uncompressed_size;

malformed_error:
	archive_set_error(&f->archive->archive, ARCHIVE_ERRNO_MISC,
	    "malformed lz4 data");
	return (ARCHIVE_FATAL);
truncated_error:
	archive_set_error(&f->archive->archive, ARCHIVE_ERRNO_MISC,
	    "truncated lz4 input");
	return (ARCHIVE_FATAL);
}

static ssize_t
lz4_filter_read_default_stream(struct archive_read_filter *f, const void **p)
{
	struct lz4 *lz4 = f->data;
	const char *read_buf;
	ssize_t ret;

	if (lz4->stage == SELECT_STREAM) {
		lz4->stage = READ_DEFAULT_STREAM;
		/* First, read a descriptor. */
		if((ret = lz4_filter_read_descriptor(f)) != ARCHIVE_OK)
			return (ret);
		lz4->stage = READ_DEFAULT_BLOCK;
	}
	/* Decompress a block. */
	ret = lz4_filter_read_data_block(f, p);

	/* If the end of block is detected, change the filter status
	   to read next stream. */
	if (ret == 0 && *p == NULL)
		lz4->stage = SELECT_STREAM;

	/* Optional processing, checking a stream sum. */
	if (lz4->flags.stream_checksum) {
		if (lz4->stage == SELECT_STREAM) {
			unsigned int checksum;
			unsigned int checksum_stream;
			read_buf = __archive_read_filter_ahead(f->upstream,
			    4, NULL);
			if (read_buf == NULL) {
				archive_set_error(&f->archive->archive,
				    ARCHIVE_ERRNO_MISC, "truncated lz4 input");
				return (ARCHIVE_FATAL);
			}
			checksum = archive_le32dec(read_buf);
			__archive_read_filter_consume(f->upstream, 4);
			checksum_stream = __archive_xxhash.XXH32_digest(
			    lz4->xxh32_state);
			lz4->xxh32_state = NULL;
			if (checksum != checksum_stream) {
#ifndef DONT_FAIL_ON_CRC_ERROR
				archive_set_error(&f->archive->archive,
				    ARCHIVE_ERRNO_MISC,
				    "lz4 stream checksum error");
				return (ARCHIVE_FATAL);
#endif
			}
		} else if (ret > 0)
			__archive_xxhash.XXH32_update(lz4->xxh32_state,
			    *p, (int)ret);
	}
	return (ret);
}

static ssize_t
lz4_filter_read_legacy_stream(struct archive_read_filter *f, const void **p)
{
	struct lz4 *lz4 = f->data;
	uint32_t compressed;
	const char *read_buf;
	ssize_t ret;

	*p = NULL;
	ret = lz4_allocate_out_block_for_legacy(f);
	if (ret != ARCHIVE_OK)
		return ret;

	/* Make sure we have 4 bytes for a block size. */
	read_buf = __archive_read_filter_ahead(f->upstream, 4, NULL);
	if (read_buf == NULL) {
		if (lz4->stage == SELECT_STREAM) {
			lz4->stage = READ_LEGACY_STREAM;
			archive_set_error(&f->archive->archive,
			    ARCHIVE_ERRNO_MISC,
			    "truncated lz4 input");
			return (ARCHIVE_FATAL);
		}
		lz4->stage = SELECT_STREAM;
		return 0;
	}
	lz4->stage = READ_LEGACY_BLOCK;
	compressed = archive_le32dec(read_buf);
	if (compressed > LZ4_COMPRESSBOUND(LEGACY_BLOCK_SIZE)) {
		lz4->stage = SELECT_STREAM;
		return 0;
	}

	/* Make sure we have a whole block. */
	read_buf = __archive_read_filter_ahead(f->upstream,
	    4 + compressed, NULL);
	if (read_buf == NULL) {
		archive_set_error(&(f->archive->archive),
		    ARCHIVE_ERRNO_MISC, "truncated lz4 input");
		return (ARCHIVE_FATAL);
	}
	ret = LZ4_decompress_safe(read_buf + 4, lz4->out_block,
	    compressed, (int)lz4->out_block_size);
	if (ret < 0) {
		archive_set_error(&(f->archive->archive),
		    ARCHIVE_ERRNO_MISC, "lz4 decompression failed");
		return (ARCHIVE_FATAL);
	}
	*p = lz4->out_block;
	lz4->unconsumed = 4 + compressed;
	return ret;
}

/*
 * Clean up the decompressor.
 */
static int
lz4_filter_close(struct archive_read_filter *f)
{
	struct lz4 *lz4 = f->data;
	int ret = ARCHIVE_OK;

	free(lz4->xxh32_state);
	free(lz4->out_block);
	free(lz4);
	return (ret);
}

#endif /* HAVE_LIBLZ4 */
